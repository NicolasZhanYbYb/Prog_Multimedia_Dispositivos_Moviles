package com.nizhvi.practica1
//Nicolas Zhan
enum class Group {
    A, B, C, D, E, F, Default
}